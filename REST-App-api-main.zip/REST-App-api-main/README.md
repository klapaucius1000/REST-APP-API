# REST-App-api
<h1> PYTHON & DJANGO BACKEND REST API App  </h1>

<h3> This is my take on Docker and DRF. You are just seeing the backend application being a bookkeeper directory. 
This application will allow you to save and categorise for yourself the books you have read.All in all,
it will be something like the Polish portal lubimyczytac.pl 
. It will be just as easy to convert to other things worth rating: films, music, food etc.</h3>.
31.08.22

work in progress...